-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping data for table return-fiverr.translations: ~21 rows (approximately)
DELETE FROM `translations`;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
INSERT INTO `translations` (`id`, `eng`, `it`, `created_at`, `updated_at`) VALUES
	(1, 'Return Station', 'Stazione di ritorno', '2021-07-17 01:15:19', '2021-07-17 01:15:19'),
	(2, 'Order Name', 'Nome ordine', '2021-07-17 01:27:53', '2021-07-17 01:27:53'),
	(3, 'Email', 'E-mail', '2021-07-17 01:29:14', '2021-07-17 01:29:15'),
	(4, 'Start Return', 'Inizio Ritorno', '2021-07-17 01:29:49', '2021-07-17 01:29:50'),
	(5, 'Review Your Return', 'Rivedi il tuo ritorno', '2021-07-17 01:44:19', '2021-07-17 01:44:20'),
	(6, 'Items You are Getting', 'Articoli che stai ricevendo', '2021-07-17 01:45:00', '2021-07-17 01:45:01'),
	(7, 'Items You are Returning', 'Articoli che stai restituendo', '2021-07-17 01:45:54', '2021-07-17 01:45:54'),
	(8, 'Summary', 'Sommario', '2021-07-17 01:46:29', '2021-07-17 01:46:30'),
	(9, 'New Items', 'Nuovi oggetti', '2021-07-17 01:48:42', '2021-07-17 01:48:43'),
	(10, 'Sub Total', 'Totale parziale', '2021-07-17 01:57:43', '2021-07-17 01:57:44'),
	(11, 'Store Credit', 'Credito in negozio', '2021-07-17 01:57:43', '2021-07-17 01:57:44'),
	(12, 'Payment Refund', 'Rimborso del pagamento', '2021-07-17 01:57:42', '2021-07-17 01:57:45'),
	(13, 'Total Returnable Amount', 'Importo totale restituibile', '2021-07-17 01:57:41', '2021-07-17 01:57:46'),
	(14, 'Total Payable Amount', 'Importo totale da pagare', '2021-07-17 01:57:41', '2021-07-17 01:57:47'),
	(15, 'Submit Return', 'Invia reso', '2021-07-17 01:57:40', '2021-07-17 01:57:47'),
	(16, 'Back', 'Indietro', '2021-07-17 01:57:40', '2021-07-17 01:57:48'),
	(17, 'Choose Items to Return or Exchange', 'Scegli gli articoli da restituire o scambiare', '2021-07-17 01:57:39', '2021-07-17 01:57:49'),
	(18, 'Returnable Until', 'Restituibile fino al', '2021-07-17 01:57:39', '2021-07-17 01:57:50'),
	(19, 'Items Selected', 'Articoli selezionati', '2021-07-17 01:57:38', '2021-07-17 01:57:50'),
	(20, 'Continue', 'Continua', '2021-07-17 01:57:38', '2021-07-17 01:57:37'),
	(21, 'Logout', 'Disconnettersi', '2021-07-17 01:57:35', '2021-07-17 01:57:36'),
	(22, 'Already Returned', 'Già restituito', '2021-07-22 14:42:52', '2021-07-22 14:42:54'),
	(23, 'Non Returnable', 'Non restituibile', NULL, NULL),
	(24, 'Return with Payment Method', 'Reso con metodo di pagamento', '2021-07-26 00:09:15', '2021-07-26 00:09:16'),
	(25, 'Exchange with', 'Scambia con', '2021-07-26 00:10:52', '2021-07-26 00:10:53'),
	(26, 'Exchange for new color / size', 'Cambio per nuovo colore/taglia', '2021-07-26 01:03:37', '2021-07-26 01:03:38'),
	(27, 'Return this Item with Refund', 'Restituisci questo articolo con rimborso', '2021-07-26 01:04:32', '2021-07-26 01:04:33'),
	(28, 'Return this Item with Store Credit', 'Restituisci questo articolo con il credito del negozio', '2021-07-26 01:05:13', '2021-07-26 01:05:14'),
	(29, 'Out of Stock', 'Esaurito', '2021-07-26 01:13:35', '2021-07-26 01:13:36');
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
